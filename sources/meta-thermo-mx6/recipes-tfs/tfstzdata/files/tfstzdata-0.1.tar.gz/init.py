#!/usr/bin/python

import sys
import csv
import datetime
import re
import os
import glob

org_folder = "/home/vasu/python/zoneinfo"
inputfile = sys.argv[1]
f_str = []


with open(inputfile, 'rt') as f:
    reader = csv.reader(f,delimiter=',')
    for i, line in enumerate(reader):
        wr_first = org_folder+'/'+line[5]
        wr_str = org_folder+'/'+line[0]+'['+line[3]+']'
        s_str = 'ln -s'+' '+'"'+wr_first+'"'+' '+'"'+wr_str+'"'
        #print(i)
        #print ('line[{}] = {}'.format(i, line))
        f_str.insert(i,s_str)
        print i, f_str[i]

for srcglob in f_str[0:-1:1]:
	print srcglob
	os.system(srcglob)
