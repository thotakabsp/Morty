{
    "framework": {
        "interpreter": "python",
        "console": false
    },
    "deeplaser-version": "${version}"
}