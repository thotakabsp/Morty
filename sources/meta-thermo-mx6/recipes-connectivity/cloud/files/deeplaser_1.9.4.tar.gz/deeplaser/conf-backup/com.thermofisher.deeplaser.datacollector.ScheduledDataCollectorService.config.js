{
    "jobs": [
    ],
    "service.pid": "com.thermofisher.deeplaser.datacollector.ScheduledDataCollectorService"
}
