{
    "config_url": "http://localhost:5000",
    "service.factoryPid": "com.thermofisher.deeplaser.update.DeepLaserUpdateService",
    "service.pid": "com.thermofisher.deeplaser.update.DeepLaserUpdateService"
}
