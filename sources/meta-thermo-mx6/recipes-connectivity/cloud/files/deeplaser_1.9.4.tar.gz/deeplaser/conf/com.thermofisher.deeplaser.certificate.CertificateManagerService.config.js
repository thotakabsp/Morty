{
    "certificates": [
        {
            "group": "device",
            "id": "root_pem",
            "location": "/home/root/deeplaser/certs/rootca.pem"
        },
        {
            "group": "device",
            "id": "device_certificate",
            "location": "/home/root/deeplaser/certs/PRODUCTION/certificate_US.pem.crt"
        }
    ],
    "device_certificate_id": "e47f04b38f8aad1a574c049d1fff5046ebe9b6ff0055b2181590e1e980b66f46",
    "device_shared_token": "DELTAKULT||Model-2016-01||123223",
    "service.pid": "com.thermofisher.deeplaser.certificate.CertificateManagerService"
}
