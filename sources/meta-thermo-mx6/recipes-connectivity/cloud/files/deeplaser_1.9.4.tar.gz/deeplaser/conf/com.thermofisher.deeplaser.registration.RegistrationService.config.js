{
    "deeplaser.iot.region": "US",
    "service.pid": "com.thermofisher.deeplaser.registration.RegistrationService"
}
