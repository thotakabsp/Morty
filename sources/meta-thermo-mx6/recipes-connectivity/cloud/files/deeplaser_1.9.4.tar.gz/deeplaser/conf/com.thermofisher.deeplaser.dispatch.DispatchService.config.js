{
    "interval_time": 300,
    "service.pid": "com.thermofisher.deeplaser.dispatch.DispatchService",
    "size_limit": 5000
}
