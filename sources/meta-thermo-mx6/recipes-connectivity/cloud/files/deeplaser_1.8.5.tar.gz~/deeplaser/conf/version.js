{"timestamp": "20181903-234231", "distribution": "deeplaser-base-distribution", "version": "1.8.5", "stage": "prod"}
