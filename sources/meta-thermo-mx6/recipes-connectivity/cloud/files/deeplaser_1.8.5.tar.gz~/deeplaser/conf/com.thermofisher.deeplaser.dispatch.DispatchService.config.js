{
    "interval_time": 60,
    "service.pid": "com.thermofisher.deeplaser.dispatch.DispatchService",
    "size_limit": 500
}
