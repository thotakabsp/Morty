{
    "certificates": [
        {
            "group": "device",
            "id": "root_pem",
            "location": "/home/root/deeplaser/certs/rootca.pem"
        },
        {
            "group": "device",
            "id": "device_certificate",
            "location": "/home/root/deeplaser/certs/TEST/certificate.pem.cer"
        }
    ],
    "device_certificate_id": "5af2ac22a00dd1f17df6233c8f1528a86f4b1726d7012d3a6bce783c2fe51a9b",
    "device_shared_token": "MODBOX||Model-2016-01||123223",
    "service.pid": "com.thermofisher.deeplaser.certificate.CertificateManagerService"
}
